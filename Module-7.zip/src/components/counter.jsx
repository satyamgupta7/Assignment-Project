import React from "react";
import { connect } from "react-redux";

function Counter({ onIncrement, onDecrement, count }) {
  return (
    <div>
      <h1>Hey Todo App</h1>
      <button onClick={onIncrement}>+</button>
      <span>{count}</span>
      <button onClick={onDecrement}>-</button> <br />
      <br />
      <input /> <button>Add Todo</button>
    </div>
  );
}

const mapStateToProps = (state) => ({ count: state });

const mapDispatchToProps = (dispatch) => ({
  onIncrement: () => dispatch({ type: "INCREMENT" }),
  onDecrement: () => dispatch({ type: "DECREMENT" }),
});

export default connect(mapStateToProps, mapDispatchToProps)(Counter);
