import Counter from "./components/counter";

function App() {
  return (
    <div className="App">
      <h1>Hello React Redux - Assignment</h1>
      <Counter />
    </div>
  );
}

export default App;
