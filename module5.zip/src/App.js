import React from "react";
import { BrowserRouter as Router, Link, Routes, Route, useParams, useMatch } from 'react-router-dom';

export default function App() {
  return (
    <Router>
      <ul>
        <li>
          <Link to="/users/1">John</Link>
        </li>
        <li>
          <Link to="/users/2">Jane</Link>
        </li>
      </ul>
      <Routes>
        <Route path='users/:userId' element={<User/>} />
        <Route path={`/users/:userId/posts/:postId`} element={<Post/>}></Route>
      </Routes>
    </Router>
  );
}

function User() {
  const { userId } = useParams();
  const { pathname, url } = useMatch('users/:userId');
  return (
    <div>
      <h3> User Id : {userId}</h3>
      <ul>
        <li>
          <Link to={`${pathname}/posts/1`}>Post1</Link>
        </li>
        <li>
          <Link to={`${pathname}/posts/2`}>Post2</Link>
        </li>
      </ul>
    </div>
  );

}

function Post() {
  const { userId, postId } = useParams();
  return (
    <h3> Post Id : {postId} By user id: {userId}</h3>
  )
}

