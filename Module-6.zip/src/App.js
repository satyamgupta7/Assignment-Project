import React from "react";
import Main from "./components/main";

const App = () => {
  return (
    <div>
      <Main />
    </div>
  );
};

export default App;
