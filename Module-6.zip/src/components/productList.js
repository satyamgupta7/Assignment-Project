const list = [
  {
    id: 1,
    name: "15 Mukhi",
    price: 15000,
    img: "https://m.media-amazon.com/images/I/810OOg88LoL._AC_UY327_FMwebp_QL65_.jpg",
    amount: 1,
  },
  {
    id: 2,
    name: "16 Mukhi",
    price: 16000,
    img: "https://m.media-amazon.com/images/I/71rmxx8P2qL._AC_UY327_FMwebp_QL65_.jpg",
    amount: 1,
  },
  {
    id: 3,
    name: "17 Mukhi",
    price: 17000,
    img: "https://m.media-amazon.com/images/I/81Gbz0XnW7L._AC_UY327_FMwebp_QL65_.jpg",
    amount: 1,
  },
  {
    id: 4,
    name: "18 Mukhi",
    price: 18000,
    img: "https://m.media-amazon.com/images/I/81Gbz0XnW7L._AC_UY327_FMwebp_QL65_.jpg",
    amount: 1,
  },
  {
    id: 5,
    name: "19 Mukhi",
    price: 19000,
    img: "https://m.media-amazon.com/images/I/71O-FI7QApL._AC_UY327_FMwebp_QL65_.jpg",
    amount: 1,
  },
  {
    id: 6,
    name: "20 Mukhi",
    price: 20000,
    img: "https://m.media-amazon.com/images/I/9173YBkMIsL._AC_UY327_FMwebp_QL65_.jpg",
    amount: 1,
  },
  {
    id: 7,
    name: "21 Mukhi ",
    price: 21000,
    img: "https://m.media-amazon.com/images/I/913sv4sex3L._AC_UY327_FMwebp_QL65_.jpg",
    amount: 1,
  },
  {
    id: 8,
    name: "22 Mukhi",
    price: 22000,
    img: "https://m.media-amazon.com/images/I/71xMttNhr7L._AC_UY327_FMwebp_QL65_.jpg",
    amount: 1,
  },
  {
    id: 9,
    name: "23 Mukhi ",
    price: 23000,
    img: "https://m.media-amazon.com/images/I/7122h3jWvEL._AC_UY327_FMwebp_QL65_.jpg",
    amount: 1,
  },
  {
    id: 10,
    name: "24 Mukhi",
    price: 24000,
    img: "https://m.media-amazon.com/images/I/7122h3jWvEL._AC_UY327_FMwebp_QL65_.jpg",
    amount: 1,
  },
];

export default list;
