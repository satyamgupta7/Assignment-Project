import React from "react";

const Product = ({ item, product, setProduct, totalprice, setTotalprice }) => {
  const { name, price, img } = item;

  function increaseProductCount() {
    setProduct(product + 1);
    setTotalprice(totalprice + price);
  }

  return (
    <div>
      <div className="cards">
        <div className="image_box">
          <img src={img} alt="" />
        </div>
        <div className="details">
          <p>{name}</p>
          <p>Price - {price}Rs</p>
          <button onClick={increaseProductCount}>Add to Cart</button>
        </div>
      </div>
    </div>
  );
};

export default Product;
