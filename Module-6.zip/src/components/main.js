import React from "react";
import Cart from "./cart";

const Main = () => {
  return (
    <div>
      <h2> Shopping Application</h2>
      <hr />
      <Cart />
    </div>
  );
};

export default Main;
