import React, { useState } from "react";
import Product from "./product";
import list from "./productList";
import "../styles/cart.css";

const Cart = () => {
  const [product, setProduct] = useState(0);
  const [totalprice, setTotalprice] = useState(0);
  return (
    <div>
      <div className="cart_box">
        <div className="cart_heading">Cart component</div>
        <div className="total_products"> Total no of Product : {product}</div>
        <div className="total_price">Total Price :{totalprice} </div>
      </div>

      <hr />
      <section>
        {list.map((item) => (
          <Product
            key={item.id}
            item={item}
            setProduct={setProduct}
            product={product}
            totalprice={totalprice}
            setTotalprice={setTotalprice}
          />
        ))}
      </section>
    </div>
  );
};

export default Cart;
